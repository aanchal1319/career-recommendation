# Career Path Recommendation System

a career path recommendation system that we had built during makeathon 9.0
